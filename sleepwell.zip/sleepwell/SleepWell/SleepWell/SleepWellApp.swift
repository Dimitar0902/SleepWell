//
//  SleepWellApp.swift
//  SleepWell
//
//  Created by Yassin Chehlaoui on 11/04/2023.
//

import SwiftUI

@main
struct SleepWellApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
